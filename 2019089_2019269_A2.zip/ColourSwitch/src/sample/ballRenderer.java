package sample;

public class ballRenderer extends Renderer {
}