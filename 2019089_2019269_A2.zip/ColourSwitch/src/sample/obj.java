package sample;

public abstract class obj{
    protected double x, y;
    public abstract void move(double t);

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

}