package sample;

public abstract class Renderer {
}
