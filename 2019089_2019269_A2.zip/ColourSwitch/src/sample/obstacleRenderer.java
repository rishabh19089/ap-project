package sample;

public class obstacleRenderer extends Renderer{
}
