package sample;

public abstract class element extends obj{
    public abstract boolean intersects(User user);
    public abstract void handleCollision(User user);
}
